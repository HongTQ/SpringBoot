package read_write_file;

import read_write_file.com.Common;

public class Main {
	public static void main(String[] args) {
		Common cm = new Common();
		cm.Menu();
	}
}
